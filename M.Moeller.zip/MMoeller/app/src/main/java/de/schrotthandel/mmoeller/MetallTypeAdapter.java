package de.schrotthandel.mmoeller;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
public class MetallTypeAdapter extends RecyclerView.Adapter<MetallTypeAdapter.MetallViewHolder> {

    private List<Metall> metallList;
    private Context context;

    public MetallTypeAdapter(List<Metall> metallList) {
        this.metallList = metallList;
    }

    @NonNull
    @Override
    public MetallViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.metal_product, parent, false);
        return new MetallViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MetallViewHolder holder, int position) {
        Metall metall = metallList.get(position);

        holder.metallNameTextView.setText(metall.getName());


    }

    @Override
    public int getItemCount() {
        return metallList.size();
    }

    // ViewHolder-Klasse
    public class MetallViewHolder extends RecyclerView.ViewHolder {
        TextView metallNameTextView;
        CardView cardView;

        public MetallViewHolder(View itemView) {
            super(itemView);
            metallNameTextView = itemView.findViewById(R.id.metallNameTextView);
            cardView = itemView.findViewById(R.id.cardview);
        }
    }
}