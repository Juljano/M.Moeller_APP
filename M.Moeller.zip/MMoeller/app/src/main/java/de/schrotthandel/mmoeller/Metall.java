package de.schrotthandel.mmoeller;

public class Metall {

    private String name;

    public Metall(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
