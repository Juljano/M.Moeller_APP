package de.schrotthandel.mmoeller;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    ActionBar actionBar;
    BottomNavigationView bottomNavigationView;

    private CustomerFormFragment customerFormFragment = new CustomerFormFragment();
    private ContactsFragment contactsFragment = new ContactsFragment();
    private BillingFragment billingFragment = new BillingFragment();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        actionBar = getSupportActionBar();

        bottomNavigationView = findViewById(R.id.navigationView);

        bottomNavigationView.setOnNavigationItemSelectedListener(navListener);

    }

    private final BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                    int id = item.getItemId();

                    if (id == R.id.menuCheck) {
                        setFragment(customerFormFragment);
                        return true;

                    } else if (id == R.id.menuBilling) {
                        setFragment(billingFragment);
                        return true;

                    } else if (id == R.id.menuContacts) {
                        setFragment(contactsFragment);
                        return true;
                    }
                    return false;
                }

                private void setFragment(Fragment fragment) {
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.mainactivity_container, fragment);
                    fragmentTransaction.commit();
                }
            };
}